UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-30T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-30T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-30T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-30T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-11-30T20:00 Europe/London'; 
