UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-11-21T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-11-21T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-21T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-11-21T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-21T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-21T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-11-21T23:00 Europe/London'; 
