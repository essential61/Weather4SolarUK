UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-11-23T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-11-23T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-11-23T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-23T23:00 Europe/London'; 
