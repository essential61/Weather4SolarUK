UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-11-26T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-11-26T18:00 Europe/London'; 
