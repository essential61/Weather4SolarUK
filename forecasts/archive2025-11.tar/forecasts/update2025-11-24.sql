UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-11-24T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Drizzle' WHERE starttime = '2025-11-24T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-24T18:00 Europe/London'; 
