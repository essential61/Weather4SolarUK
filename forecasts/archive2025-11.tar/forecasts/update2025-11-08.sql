UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-11-08T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-11-08T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-11-08T14:00 Europe/London'; 
