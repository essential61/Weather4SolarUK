UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-01T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-11-01T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-11-01T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-11-01T16:00 Europe/London'; 
