UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-11-12T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-11-12T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-11-12T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-11-12T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-11-12T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-11-12T19:00 Europe/London'; 
