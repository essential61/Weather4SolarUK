UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-30T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-30T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-30T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-30T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-30T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-30T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-08-30T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-08-30T23:00 Europe/London'; 
