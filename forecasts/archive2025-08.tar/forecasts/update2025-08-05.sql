UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-08-05T17:00 Europe/London';
