UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-16T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-16T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-16T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-16T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-08-16T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-08-16T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-08-16T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-08-16T23:00 Europe/London'; 
