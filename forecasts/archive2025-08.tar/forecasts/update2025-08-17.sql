UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-17T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-17T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-08-17T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-08-17T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-08-17T23:00 Europe/London'; 
