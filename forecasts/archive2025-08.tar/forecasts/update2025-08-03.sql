UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-03T10:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-03T13:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-03T15:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-03T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-03T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-03T17:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-08-03T21:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-08-03T22:00 Europe/London';
