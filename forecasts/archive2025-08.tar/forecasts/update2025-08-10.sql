UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-10T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-10T12:00 Europe/London'; 
