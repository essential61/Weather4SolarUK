UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-04T08:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-04T09:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-08-04T09:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-04T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-08-04T13:00 Europe/London';
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-08-04T15:00 Europe/London';
