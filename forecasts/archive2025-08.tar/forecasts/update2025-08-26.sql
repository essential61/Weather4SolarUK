UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-26T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-26T13:00 Europe/London'; 
