UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-08-12T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-08-12T07:00 Europe/London'; 
