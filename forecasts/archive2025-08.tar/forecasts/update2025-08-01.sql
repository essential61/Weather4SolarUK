UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-01T10:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-08-01T13:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-08-01T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-08-01T17:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-08-01T19:00 Europe/London';
