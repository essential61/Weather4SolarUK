-- created 2026-09-29
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T11:00 Europe/London', 'Sunny intervals');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T12:00 Europe/London', 'Sunny intervals');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T13:00 Europe/London', 'Sunny intervals');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T14:00 Europe/London', 'Cloudy');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T15:00 Europe/London', 'Cloudy');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T16:00 Europe/London', 'Cloudy');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T17:00 Europe/London', 'Sunny intervals');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T18:00 Europe/London', 'Sunny intervals');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T19:00 Europe/London', 'Partly cloudy night');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T20:00 Europe/London', 'Partly cloudy night');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T21:00 Europe/London', 'Clear night');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T22:00 Europe/London', 'Clear night');
INSERT INTO forecasts (starttime, sky) VALUES ('2026-09-29T23:00 Europe/London', 'Clear night');
