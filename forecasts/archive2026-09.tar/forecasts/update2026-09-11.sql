UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-09-11T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-09-11T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-09-11T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-09-11T22:00 Europe/London'; 
