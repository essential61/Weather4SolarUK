UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-20T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-20T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-20T17:00 Europe/London';
