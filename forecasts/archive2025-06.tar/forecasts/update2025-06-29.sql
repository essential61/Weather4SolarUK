UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-29T18:00 Europe/London';
