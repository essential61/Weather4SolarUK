UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-22T08:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-22T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-22T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-22T17:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-22T18:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-22T19:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-22T20:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-22T21:00 Europe/London';
