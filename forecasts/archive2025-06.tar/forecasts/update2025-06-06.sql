UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-06T06:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-06T07:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-06-06T08:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-06T09:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-06T10:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-06T11:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-06T12:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-06T19:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-06T20:00 Europe/London';
