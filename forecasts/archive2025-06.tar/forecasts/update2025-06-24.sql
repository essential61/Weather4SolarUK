UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-24T06:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-24T07:00 Europe/London';
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-06-24T21:00 Europe/London';
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-06-24T22:00 Europe/London';
