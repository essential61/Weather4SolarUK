UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-01T06:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-01T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-01T16:00 Europe/London';
