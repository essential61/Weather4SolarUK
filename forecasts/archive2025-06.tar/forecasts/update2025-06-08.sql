UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-08T06:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-08T08:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-08T13:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-08T15:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-08T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-08T22:00 Europe/London';
