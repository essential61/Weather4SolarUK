UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-28T06:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-28T11:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-28T12:00 Europe/London';
