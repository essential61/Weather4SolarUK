UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-10T15:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-06-10T15:00 Europe/London';
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-06-10T22:00 Europe/London';
