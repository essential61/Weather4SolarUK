UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T08:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-06-23T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T17:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-23T18:00 Europe/London';
