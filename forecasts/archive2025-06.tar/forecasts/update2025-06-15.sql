UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-15T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-15T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-15T17:00 Europe/London';
