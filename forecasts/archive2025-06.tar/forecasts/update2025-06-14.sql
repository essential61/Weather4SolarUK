UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-14T12:00 Europe/London';
