UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-26T08:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-26T11:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-06-26T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-26T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-26T19:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-26T20:00 Europe/London';
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-06-26T21:00 Europe/London';
