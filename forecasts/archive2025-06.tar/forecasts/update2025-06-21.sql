UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-21T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-06-21T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-21T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-21T17:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-21T18:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-21T19:00 Europe/London';
