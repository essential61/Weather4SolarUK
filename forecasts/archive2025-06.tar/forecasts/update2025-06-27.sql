UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-27T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-27T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-27T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-27T17:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-27T20:00 Europe/London';
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-06-27T21:00 Europe/London';
