UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-06-25T20:00 Europe/London';
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-06-25T21:00 Europe/London';
