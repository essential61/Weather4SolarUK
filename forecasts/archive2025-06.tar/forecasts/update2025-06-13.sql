UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-13T06:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-13T07:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-13T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-06-13T13:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-13T21:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-06-13T22:00 Europe/London';
