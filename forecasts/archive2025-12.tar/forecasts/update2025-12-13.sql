UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-12-13T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-12-13T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-12-13T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-12-13T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-13T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-13T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-13T23:00 Europe/London'; 
