UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-12-07T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Drizzle' WHERE starttime = '2025-12-07T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-12-07T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-12-07T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-12-07T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-12-07T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-07T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-12-07T23:00 Europe/London'; 
