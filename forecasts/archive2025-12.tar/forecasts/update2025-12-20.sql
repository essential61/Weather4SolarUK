UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-20T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-12-20T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-20T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-20T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Fog' WHERE starttime = '2025-12-20T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Fog' WHERE starttime = '2025-12-20T23:00 Europe/London'; 
