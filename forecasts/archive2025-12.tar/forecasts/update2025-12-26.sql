UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-12-26T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-12-26T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-12-26T21:00 Europe/London'; 
