UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-12-27T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-12-27T12:00 Europe/London'; 
