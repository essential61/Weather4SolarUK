UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-12-14T15:00 Europe/London'; 
