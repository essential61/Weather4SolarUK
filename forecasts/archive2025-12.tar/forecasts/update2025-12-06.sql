UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-12-06T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-12-06T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-12-06T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-12-06T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-12-06T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-12-06T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-12-06T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-06T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-12-06T23:00 Europe/London'; 
