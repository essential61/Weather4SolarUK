UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-12-01T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-12-01T22:00 Europe/London'; 
