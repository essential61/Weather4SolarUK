UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-12-12T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-12-12T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-12-12T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-12-12T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-12-12T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-12-12T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-12-12T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-12-12T23:00 Europe/London'; 
