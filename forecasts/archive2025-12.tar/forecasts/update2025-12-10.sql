UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-12-10T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-12-10T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-12-10T12:00 Europe/London'; 
