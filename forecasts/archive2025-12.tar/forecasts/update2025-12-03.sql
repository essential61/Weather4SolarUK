UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-12-03T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-12-03T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-12-03T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-12-03T18:00 Europe/London'; 
