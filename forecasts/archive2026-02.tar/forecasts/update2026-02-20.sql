UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2026-02-20T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-02-20T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-02-20T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Drizzle' WHERE starttime = '2026-02-20T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-02-20T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2026-02-20T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-02-20T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-02-20T22:00 Europe/London'; 
