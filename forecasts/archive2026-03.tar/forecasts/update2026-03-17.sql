UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-03-17T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-03-17T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-03-17T11:00 Europe/London'; 
