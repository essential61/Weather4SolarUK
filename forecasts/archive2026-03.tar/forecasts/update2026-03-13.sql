UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-03-13T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-03-13T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-03-13T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2026-03-13T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-03-13T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-03-13T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-03-13T23:00 Europe/London'; 
