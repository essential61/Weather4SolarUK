UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-03-29T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-03-29T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-03-29T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Drizzle' WHERE starttime = '2026-03-29T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-03-29T20:00 Europe/London'; 
