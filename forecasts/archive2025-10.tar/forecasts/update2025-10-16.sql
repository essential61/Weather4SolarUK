UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-10-16T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-10-16T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-10-16T12:00 Europe/London'; 
