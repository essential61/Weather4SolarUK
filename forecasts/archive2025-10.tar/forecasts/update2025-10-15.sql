UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-15T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-15T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-15T19:00 Europe/London'; 
