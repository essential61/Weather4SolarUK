UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-27T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-10-27T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-27T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-27T19:00 Europe/London'; 
