UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-10-22T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-10-22T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-10-22T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-10-22T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-10-22T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-22T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-10-22T19:00 Europe/London'; 
