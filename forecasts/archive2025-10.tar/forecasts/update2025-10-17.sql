UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-17T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-10-17T23:00 Europe/London'; 
