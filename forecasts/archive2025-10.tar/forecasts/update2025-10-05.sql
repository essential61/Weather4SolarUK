UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-10-05T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-10-05T16:00 Europe/London'; 
