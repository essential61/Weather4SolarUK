UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-21T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-21T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-21T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-21T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-07-21T18:00 Europe/London';
