UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-26T08:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-26T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-07-26T13:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-26T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-26T15:00 Europe/London';
