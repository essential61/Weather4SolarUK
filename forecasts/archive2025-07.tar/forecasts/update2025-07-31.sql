UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-31T07:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-31T07:00 Europe/London';
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-31T11:00 Europe/London';
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-31T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-31T13:00 Europe/London';
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-31T15:00 Europe/London';
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-31T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-31T16:00 Europe/London';
