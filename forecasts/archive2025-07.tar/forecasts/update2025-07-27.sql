UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-27T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-27T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-27T16:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-27T22:00 Europe/London';
