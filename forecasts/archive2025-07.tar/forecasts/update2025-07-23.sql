UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-23T09:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-23T09:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-23T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-23T17:00 Europe/London';
