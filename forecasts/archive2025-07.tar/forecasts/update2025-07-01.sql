UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-01T08:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-01T09:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-01T10:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-07-01T21:00 Europe/London';
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-07-01T22:00 Europe/London';
