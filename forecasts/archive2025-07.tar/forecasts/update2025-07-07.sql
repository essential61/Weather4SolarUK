UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-07T07:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-07T09:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-07T12:00 Europe/London';
