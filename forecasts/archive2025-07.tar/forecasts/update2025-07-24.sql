UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-24T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-24T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-24T16:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-24T17:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-24T18:00 Europe/London';
