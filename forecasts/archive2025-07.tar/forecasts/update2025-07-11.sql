UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-11T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-11T17:00 Europe/London';
