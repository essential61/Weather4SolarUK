UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-02T06:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-02T07:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-02T08:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-02T09:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-02T11:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-02T13:00 Europe/London';
