UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-09T08:00 Europe/London';
