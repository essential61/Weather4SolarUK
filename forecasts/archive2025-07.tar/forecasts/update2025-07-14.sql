UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-14T11:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-14T11:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-14T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-07-14T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-14T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-14T17:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-14T19:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-14T20:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-07-14T22:00 Europe/London';
