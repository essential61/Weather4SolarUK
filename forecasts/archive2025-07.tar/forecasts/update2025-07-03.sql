UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-03T10:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-03T19:00 Europe/London';
