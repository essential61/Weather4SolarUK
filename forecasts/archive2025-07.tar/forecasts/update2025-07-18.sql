UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-18T09:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-18T09:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-18T10:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-18T11:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-18T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-18T19:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-18T20:00 Europe/London';
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-07-18T21:00 Europe/London';
