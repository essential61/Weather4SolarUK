UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-15T07:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-15T07:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-15T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-15T17:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-15T20:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-15T21:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-07-15T22:00 Europe/London';
