UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-04T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-04T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-04T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-04T17:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-04T18:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-04T19:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-07-04T20:00 Europe/London';
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-07-04T21:00 Europe/London';
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-07-04T22:00 Europe/London';
