UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-19T06:00 Europe/London';
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-07-19T10:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-19T11:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-19T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-19T13:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-07-19T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-07-19T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-19T16:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-19T21:00 Europe/London';
