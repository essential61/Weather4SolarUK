UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-28T09:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-28T11:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-28T11:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-28T12:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-28T13:00 Europe/London';
