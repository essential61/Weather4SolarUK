UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-25T11:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-25T12:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-25T20:00 Europe/London';
