UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-22T07:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-22T07:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-22T08:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-07-22T13:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-22T16:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-22T17:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-07-22T18:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-07-22T20:00 Europe/London';
