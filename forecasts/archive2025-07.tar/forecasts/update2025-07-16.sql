UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-07-16T17:00 Europe/London';
