UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-02T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-02T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-02T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-02T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-02T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-02T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-09-02T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-09-02T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-09-02T23:00 Europe/London'; 
