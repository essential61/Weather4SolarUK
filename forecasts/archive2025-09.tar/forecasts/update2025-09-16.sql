UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-09-16T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-16T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-16T21:00 Europe/London'; 
