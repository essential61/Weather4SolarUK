UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-08T12:00 Europe/London'; 
