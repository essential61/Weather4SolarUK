UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-05T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-05T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-09-05T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-09-05T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-09-05T20:00 Europe/London'; 
