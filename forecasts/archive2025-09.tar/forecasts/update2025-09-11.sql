UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-11T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy shower day' WHERE starttime = '2025-09-11T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-09-11T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-09-11T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-09-11T23:00 Europe/London'; 
