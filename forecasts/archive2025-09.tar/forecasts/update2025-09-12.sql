UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-09-12T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-12T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-12T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy shower day' WHERE starttime = '2025-09-12T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-09-12T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy shower night' WHERE starttime = '2025-09-12T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-12T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-12T23:00 Europe/London'; 
