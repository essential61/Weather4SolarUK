UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-09-01T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy shower day' WHERE starttime = '2025-09-01T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-09-01T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy shower day' WHERE starttime = '2025-09-01T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-09-01T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-09-01T20:00 Europe/London'; 
