UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-28T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-09-28T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-09-28T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-28T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-28T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-28T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-28T23:00 Europe/London'; 
