UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-09-14T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-09-14T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-09-14T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-14T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-09-14T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-14T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2025-09-14T23:00 Europe/London'; 
