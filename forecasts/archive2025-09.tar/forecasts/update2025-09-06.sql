UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-06T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-06T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-09-06T11:00 Europe/London'; 
