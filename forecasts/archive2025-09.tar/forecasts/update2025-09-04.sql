UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-04T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-09-04T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-09-04T18:00 Europe/London'; 
