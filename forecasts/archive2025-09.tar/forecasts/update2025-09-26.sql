UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-26T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-09-26T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-26T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2025-09-26T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-09-26T22:00 Europe/London'; 
