UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-29T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-29T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-29T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2025-09-29T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-29T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-29T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-29T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-29T21:00 Europe/London'; 
