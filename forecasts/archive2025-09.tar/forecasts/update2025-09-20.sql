UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-09-20T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower day' WHERE starttime = '2025-09-20T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2025-09-20T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-09-20T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-09-20T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-09-20T23:00 Europe/London'; 
