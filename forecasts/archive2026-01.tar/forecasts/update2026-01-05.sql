UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-01-05T15:00 Europe/London'; 
