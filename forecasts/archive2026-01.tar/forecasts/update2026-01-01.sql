UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-01T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-01T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-01T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-01T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-01T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-01T20:00 Europe/London'; 
