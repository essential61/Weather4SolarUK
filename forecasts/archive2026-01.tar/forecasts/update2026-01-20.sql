UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-20T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-20T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2026-01-20T23:00 Europe/London'; 
