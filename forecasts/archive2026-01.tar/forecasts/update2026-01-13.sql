UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-13T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-13T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-13T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-13T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-13T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-13T23:00 Europe/London'; 
