UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-01-12T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-12T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-12T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-01-12T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-12T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-12T17:00 Europe/London'; 
