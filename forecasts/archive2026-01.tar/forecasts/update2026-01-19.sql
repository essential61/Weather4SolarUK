UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-19T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Fog' WHERE starttime = '2026-01-19T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-19T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-19T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Drizzle' WHERE starttime = '2026-01-19T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-19T23:00 Europe/London'; 
