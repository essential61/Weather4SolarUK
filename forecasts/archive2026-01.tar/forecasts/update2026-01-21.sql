UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-21T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-21T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-21T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-21T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-21T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-21T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-21T15:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-21T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Drizzle' WHERE starttime = '2026-01-21T21:00 Europe/London'; 
