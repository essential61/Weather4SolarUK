UPDATE forecasts SET sky = 'Sleet shower' WHERE starttime = '2026-01-02T05:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sleet shower' WHERE starttime = '2026-01-02T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-02T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-01-02T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-01-02T09:00 Europe/London'; 
