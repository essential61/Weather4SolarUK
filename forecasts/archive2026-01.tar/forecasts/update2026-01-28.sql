UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-28T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-28T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-28T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-28T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-28T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-28T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Fog' WHERE starttime = '2026-01-28T23:00 Europe/London'; 
