UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-18T06:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-18T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-18T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-18T09:00 Europe/London'; 
UPDATE forecasts SET sky = 'Mist' WHERE starttime = '2026-01-18T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-18T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-18T17:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-18T18:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-18T19:00 Europe/London'; 
