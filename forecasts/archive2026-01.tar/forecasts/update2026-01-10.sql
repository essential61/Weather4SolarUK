UPDATE forecasts SET sky = 'Clear night' WHERE starttime = '2026-01-10T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-10T22:00 Europe/London'; 
