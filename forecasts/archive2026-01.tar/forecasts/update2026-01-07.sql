UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2026-01-07T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2026-01-07T08:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2026-01-07T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2026-01-07T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2026-01-07T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-07T20:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-07T21:00 Europe/London'; 
