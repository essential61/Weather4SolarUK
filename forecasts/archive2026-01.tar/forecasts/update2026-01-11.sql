UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-11T07:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-11T10:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-11T11:00 Europe/London'; 
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2026-01-11T12:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-11T19:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light shower night' WHERE starttime = '2026-01-11T22:00 Europe/London'; 
