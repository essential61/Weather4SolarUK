UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-24T13:00 Europe/London'; 
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2026-01-24T14:00 Europe/London'; 
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2026-01-24T16:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-24T21:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-24T22:00 Europe/London'; 
UPDATE forecasts SET sky = 'Heavy rain' WHERE starttime = '2026-01-24T23:00 Europe/London'; 
