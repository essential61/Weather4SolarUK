UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-29T13:00 Europe/London';
