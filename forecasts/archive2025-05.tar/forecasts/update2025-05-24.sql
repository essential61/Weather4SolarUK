UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-24T06:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-24T09:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-24T11:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-24T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-24T17:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-24T18:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-24T20:00 Europe/London';
