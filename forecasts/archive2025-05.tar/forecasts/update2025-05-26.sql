UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-26T08:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T12:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T15:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T17:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T19:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T20:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T21:00 Europe/London';
UPDATE forecasts SET sky = 'Light rain' WHERE starttime = '2025-05-26T22:00 Europe/London';
