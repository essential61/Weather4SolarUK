UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-28T09:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-28T10:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-28T11:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-28T12:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-28T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny day' WHERE starttime = '2025-05-28T19:00 Europe/London';
UPDATE forecasts SET sky = 'Partly cloudy night' WHERE starttime = '2025-05-28T21:00 Europe/London';
