UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-25T06:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-25T07:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-25T08:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-05-25T13:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-05-25T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-05-25T15:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-05-25T16:00 Europe/London';
