UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-22T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-22T15:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-22T16:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-22T17:00 Europe/London';
UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-22T18:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-05-22T19:00 Europe/London';
