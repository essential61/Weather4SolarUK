UPDATE forecasts SET sky = 'Overcast' WHERE starttime = '2025-05-21T11:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-21T12:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-21T13:00 Europe/London';
UPDATE forecasts SET sky = 'Cloudy' WHERE starttime = '2025-05-21T16:00 Europe/London';
UPDATE forecasts SET sky = 'Sunny intervals' WHERE starttime = '2025-05-21T19:00 Europe/London';
